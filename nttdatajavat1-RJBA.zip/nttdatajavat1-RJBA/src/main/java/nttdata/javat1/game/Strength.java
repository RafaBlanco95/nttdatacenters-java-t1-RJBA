package nttdata.javat1.game;
/**
 * Enum que recoje los valores de fuerza que pueden adoptar los jugadores 
 * 
 * @author Rafael Blanco
 *
 */
public enum Strength {
	
	weakest, weak, strong, prettyStrong, Hulk, nonSpecified

}
